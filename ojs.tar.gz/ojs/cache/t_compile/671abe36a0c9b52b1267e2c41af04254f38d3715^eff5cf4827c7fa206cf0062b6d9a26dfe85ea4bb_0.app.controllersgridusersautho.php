<?php
/* Smarty version 3.1.33, created on 2019-10-28 16:18:17
  from 'app:controllersgridusersautho' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db714c9169567_84711658',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eff5cf4827c7fa206cf0062b6d9a26dfe85ea4bb' => 
    array (
      0 => 'app:controllersgridusersautho',
      1 => 1559234240,
      2 => 'app',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db714c9169567_84711658 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['isPrincipalContact']->value) {?>
	<div id="isChecked"><div href="#" class='pkp_helpers_container_center checked'></div></div>
<?php }?>

<?php }
}
