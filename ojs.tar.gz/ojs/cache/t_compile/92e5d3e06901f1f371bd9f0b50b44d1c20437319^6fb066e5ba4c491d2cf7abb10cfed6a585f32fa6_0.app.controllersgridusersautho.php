<?php
/* Smarty version 3.1.33, created on 2019-10-28 16:18:17
  from 'app:controllersgridusersautho' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.33',
  'unifunc' => 'content_5db714c916e486_73050284',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '6fb066e5ba4c491d2cf7abb10cfed6a585f32fa6' => 
    array (
      0 => 'app:controllersgridusersautho',
      1 => 1559234240,
      2 => 'app',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5db714c916e486_73050284 (Smarty_Internal_Template $_smarty_tpl) {
if ($_smarty_tpl->tpl_vars['includeInBrowse']->value) {?>
	<div id="isChecked"><div href="#" class='pkp_helpers_container_center checked'></div></div>
<?php }?>

<?php }
}
